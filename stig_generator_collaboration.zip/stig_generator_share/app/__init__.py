"""STIG Generator Application."""








